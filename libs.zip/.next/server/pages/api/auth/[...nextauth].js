"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth/[...nextauth]";
exports.ids = ["pages/api/auth/[...nextauth]"];
exports.modules = {

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ "bcryptjs":
/*!***************************!*\
  !*** external "bcryptjs" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ "next-auth":
/*!****************************!*\
  !*** external "next-auth" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ "next-auth/providers/credentials":
/*!**************************************************!*\
  !*** external "next-auth/providers/credentials" ***!
  \**************************************************/
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ "(api)/./libs/auth.ts":
/*!**********************!*\
  !*** ./libs/auth.ts ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"hashPassword\": () => (/* binding */ hashPassword),\n/* harmony export */   \"verifyPassword\": () => (/* binding */ verifyPassword)\n/* harmony export */ });\n/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bcryptjs */ \"bcryptjs\");\n/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_0__);\n\nasync function hashPassword(password) {\n    const hashedPassword = await (0,bcryptjs__WEBPACK_IMPORTED_MODULE_0__.hash)(password, 12);\n    return hashedPassword;\n}\nasync function verifyPassword(password, hashedPassword) {\n    const isValid = await (0,bcryptjs__WEBPACK_IMPORTED_MODULE_0__.compare)(password, hashedPassword);\n    return isValid;\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9saWJzL2F1dGgudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUF5QztBQUVsQyxlQUFlRSxhQUFhQyxRQUFnQixFQUFtQjtJQUNwRSxNQUFNQyxpQkFBaUIsTUFBTUosOENBQUlBLENBQUNHLFVBQVU7SUFDNUMsT0FBT0M7QUFDVCxDQUFDO0FBRU0sZUFBZUMsZUFDcEJGLFFBQWdCLEVBQ2hCQyxjQUFzQixFQUNKO0lBQ2xCLE1BQU1FLFVBQVUsTUFBTUwsaURBQU9BLENBQUNFLFVBQVVDO0lBQ3hDLE9BQU9FO0FBQ1QsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2RicC1jaGF0Ly4vbGlicy9hdXRoLnRzP2UwMDAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaGFzaCwgY29tcGFyZSB9IGZyb20gXCJiY3J5cHRqc1wiO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGFzaFBhc3N3b3JkKHBhc3N3b3JkOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBoYXNoZWRQYXNzd29yZCA9IGF3YWl0IGhhc2gocGFzc3dvcmQsIDEyKTtcbiAgcmV0dXJuIGhhc2hlZFBhc3N3b3JkO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdmVyaWZ5UGFzc3dvcmQoXG4gIHBhc3N3b3JkOiBzdHJpbmcsXG4gIGhhc2hlZFBhc3N3b3JkOiBzdHJpbmdcbik6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCBpc1ZhbGlkID0gYXdhaXQgY29tcGFyZShwYXNzd29yZCwgaGFzaGVkUGFzc3dvcmQpO1xuICByZXR1cm4gaXNWYWxpZDtcbn1cbiJdLCJuYW1lcyI6WyJoYXNoIiwiY29tcGFyZSIsImhhc2hQYXNzd29yZCIsInBhc3N3b3JkIiwiaGFzaGVkUGFzc3dvcmQiLCJ2ZXJpZnlQYXNzd29yZCIsImlzVmFsaWQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./libs/auth.ts\n");

/***/ }),

/***/ "(api)/./pages/api/auth/[...nextauth].tsx":
/*!******************************************!*\
  !*** ./pages/api/auth/[...nextauth].tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-auth */ \"next-auth\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/providers/credentials */ \"next-auth/providers/credentials\");\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @prisma/client */ \"@prisma/client\");\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _libs_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../libs/auth */ \"(api)/./libs/auth.ts\");\n\n\n\n\nlet prisma = new _prisma_client__WEBPACK_IMPORTED_MODULE_2__.PrismaClient();\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_auth__WEBPACK_IMPORTED_MODULE_0___default()({\n    providers: [\n        next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1___default()({\n            name: \"Credentials\",\n            credentials: {\n                id: {\n                    label: \"유저 아이디\",\n                    type: \"id\",\n                    placeholder: \"id\"\n                },\n                password: {\n                    label: \"유저 패스워드\",\n                    type: \"password\",\n                    placeholder: \"password\"\n                }\n            },\n            async authorize (credentials) {\n                const user = await prisma.user.findUnique({\n                    where: {\n                        id: String(credentials?.id)\n                    },\n                    select: {\n                        id: true,\n                        name: true,\n                        address: true,\n                        password: true,\n                        user_srl: true,\n                        profile_url: true\n                    }\n                });\n                if (!user) {\n                    throw new Error(\"유저를 찾을 수 없습니다.\");\n                }\n                const isValid = await (0,_libs_auth__WEBPACK_IMPORTED_MODULE_3__.verifyPassword)(credentials.password, user.password);\n                if (!isValid) {\n                    throw new Error(\"비밀번호가 틀렸습니다.\");\n                }\n                return {\n                    id: user.user_srl,\n                    email: user.id,\n                    name: user.name,\n                    image: user.profile_url\n                };\n            }\n        })\n    ],\n    callbacks: {\n        session: async ({ session , token  })=>{\n            if (session?.user) {\n                session.user.id = token.uid;\n            }\n            return session;\n        },\n        jwt: async ({ user , token  })=>{\n            if (user) {\n                token.uid = user.id;\n            }\n            return token;\n        }\n    },\n    session: {\n        strategy: \"jwt\"\n    }\n}));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFpQztBQUNpQztBQUNwQjtBQUNNO0FBRXBELElBQUlJLFNBQVMsSUFBSUYsd0RBQVlBO0FBRTdCLGlFQUFlRixnREFBUUEsQ0FBQztJQUN0QkssV0FBVztRQUNUSixzRUFBbUJBLENBQUM7WUFDbEJLLE1BQU07WUFDTkMsYUFBYTtnQkFDWEMsSUFBSTtvQkFBRUMsT0FBTztvQkFBVUMsTUFBTTtvQkFBTUMsYUFBYTtnQkFBSztnQkFDckRDLFVBQVU7b0JBQ1JILE9BQU87b0JBQ1BDLE1BQU07b0JBQ05DLGFBQWE7Z0JBQ2Y7WUFDRjtZQUNBLE1BQU1FLFdBQVVOLFdBQVcsRUFBRTtnQkFDM0IsTUFBTU8sT0FBTyxNQUFNVixPQUFPVSxJQUFJLENBQUNDLFVBQVUsQ0FBQztvQkFDeENDLE9BQU87d0JBQ0xSLElBQUlTLE9BQU9WLGFBQWFDO29CQUMxQjtvQkFDQVUsUUFBUTt3QkFDTlYsSUFBSSxJQUFJO3dCQUNSRixNQUFNLElBQUk7d0JBQ1ZhLFNBQVMsSUFBSTt3QkFDYlAsVUFBVSxJQUFJO3dCQUNkUSxVQUFVLElBQUk7d0JBQ2RDLGFBQWEsSUFBSTtvQkFDbkI7Z0JBQ0Y7Z0JBRUEsSUFBSSxDQUFDUCxNQUFNO29CQUNULE1BQU0sSUFBSVEsTUFBTSxrQkFBa0I7Z0JBQ3BDLENBQUM7Z0JBRUQsTUFBTUMsVUFBVSxNQUFNcEIsMERBQWNBLENBQ2xDSSxZQUFhSyxRQUFRLEVBQ3JCRSxLQUFLRixRQUFRO2dCQUdmLElBQUksQ0FBQ1csU0FBUztvQkFDWixNQUFNLElBQUlELE1BQU0sZ0JBQWdCO2dCQUNsQyxDQUFDO2dCQUNELE9BQU87b0JBQ0xkLElBQUlNLEtBQU1NLFFBQVE7b0JBQ2xCSSxPQUFPVixLQUFNTixFQUFFO29CQUNmRixNQUFNUSxLQUFNUixJQUFJO29CQUNoQm1CLE9BQU9YLEtBQU1PLFdBQVc7Z0JBQzFCO1lBQ0Y7UUFDRjtLQUNEO0lBRURLLFdBQVc7UUFDVEMsU0FBUyxPQUFPLEVBQUVBLFFBQU8sRUFBRUMsTUFBSyxFQUFFLEdBQUs7WUFDckMsSUFBSUQsU0FBU2IsTUFBTTtnQkFDakJhLFFBQVFiLElBQUksQ0FBQ04sRUFBRSxHQUFHb0IsTUFBTUMsR0FBRztZQUM3QixDQUFDO1lBQ0QsT0FBT0Y7UUFDVDtRQUNBRyxLQUFLLE9BQU8sRUFBRWhCLEtBQUksRUFBRWMsTUFBSyxFQUFFLEdBQUs7WUFDOUIsSUFBSWQsTUFBTTtnQkFDUmMsTUFBTUMsR0FBRyxHQUFHZixLQUFLTixFQUFFO1lBQ3JCLENBQUM7WUFDRCxPQUFPb0I7UUFDVDtJQUNGO0lBQ0FELFNBQVM7UUFDUEksVUFBVTtJQUNaO0FBQ0YsRUFBRSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZGJwLWNoYXQvLi9wYWdlcy9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdLnRzeD9jMTI1Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBOZXh0QXV0aCBmcm9tIFwibmV4dC1hdXRoXCI7XG5pbXBvcnQgQ3JlZGVudGlhbHNQcm92aWRlciBmcm9tIFwibmV4dC1hdXRoL3Byb3ZpZGVycy9jcmVkZW50aWFsc1wiO1xuaW1wb3J0IHsgUHJpc21hQ2xpZW50IH0gZnJvbSBcIkBwcmlzbWEvY2xpZW50XCI7XG5pbXBvcnQgeyB2ZXJpZnlQYXNzd29yZCB9IGZyb20gXCIuLi8uLi8uLi9saWJzL2F1dGhcIjtcblxubGV0IHByaXNtYSA9IG5ldyBQcmlzbWFDbGllbnQoKTtcblxuZXhwb3J0IGRlZmF1bHQgTmV4dEF1dGgoe1xuICBwcm92aWRlcnM6IFtcbiAgICBDcmVkZW50aWFsc1Byb3ZpZGVyKHtcbiAgICAgIG5hbWU6IFwiQ3JlZGVudGlhbHNcIixcbiAgICAgIGNyZWRlbnRpYWxzOiB7XG4gICAgICAgIGlkOiB7IGxhYmVsOiBcIuycoOyggCDslYTsnbTrlJRcIiwgdHlwZTogXCJpZFwiLCBwbGFjZWhvbGRlcjogXCJpZFwiIH0sXG4gICAgICAgIHBhc3N3b3JkOiB7XG4gICAgICAgICAgbGFiZWw6IFwi7Jyg7KCAIO2MqOyKpOybjOuTnFwiLFxuICAgICAgICAgIHR5cGU6IFwicGFzc3dvcmRcIixcbiAgICAgICAgICBwbGFjZWhvbGRlcjogXCJwYXNzd29yZFwiLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIGFzeW5jIGF1dGhvcml6ZShjcmVkZW50aWFscykge1xuICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgcHJpc21hLnVzZXIuZmluZFVuaXF1ZSh7XG4gICAgICAgICAgd2hlcmU6IHtcbiAgICAgICAgICAgIGlkOiBTdHJpbmcoY3JlZGVudGlhbHM/LmlkKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHNlbGVjdDoge1xuICAgICAgICAgICAgaWQ6IHRydWUsXG4gICAgICAgICAgICBuYW1lOiB0cnVlLFxuICAgICAgICAgICAgYWRkcmVzczogdHJ1ZSxcbiAgICAgICAgICAgIHBhc3N3b3JkOiB0cnVlLFxuICAgICAgICAgICAgdXNlcl9zcmw6IHRydWUsXG4gICAgICAgICAgICBwcm9maWxlX3VybDogdHJ1ZSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIXVzZXIpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCLsnKDsoIDrpbwg7LC+7J2EIOyImCDsl4bsirXri4jri6QuXCIpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgaXNWYWxpZCA9IGF3YWl0IHZlcmlmeVBhc3N3b3JkKFxuICAgICAgICAgIGNyZWRlbnRpYWxzIS5wYXNzd29yZCxcbiAgICAgICAgICB1c2VyLnBhc3N3b3JkXG4gICAgICAgICk7XG5cbiAgICAgICAgaWYgKCFpc1ZhbGlkKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwi67mE67CA67KI7Zi46rCAIO2LgOuguOyKteuLiOuLpC5cIik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBpZDogdXNlciEudXNlcl9zcmwsXG4gICAgICAgICAgZW1haWw6IHVzZXIhLmlkLFxuICAgICAgICAgIG5hbWU6IHVzZXIhLm5hbWUsXG4gICAgICAgICAgaW1hZ2U6IHVzZXIhLnByb2ZpbGVfdXJsLFxuICAgICAgICB9O1xuICAgICAgfSxcbiAgICB9KSxcbiAgXSxcblxuICBjYWxsYmFja3M6IHtcbiAgICBzZXNzaW9uOiBhc3luYyAoeyBzZXNzaW9uLCB0b2tlbiB9KSA9PiB7XG4gICAgICBpZiAoc2Vzc2lvbj8udXNlcikge1xuICAgICAgICBzZXNzaW9uLnVzZXIuaWQgPSB0b2tlbi51aWQgYXMgc3RyaW5nO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHNlc3Npb247XG4gICAgfSxcbiAgICBqd3Q6IGFzeW5jICh7IHVzZXIsIHRva2VuIH0pID0+IHtcbiAgICAgIGlmICh1c2VyKSB7XG4gICAgICAgIHRva2VuLnVpZCA9IHVzZXIuaWQ7XG4gICAgICB9XG4gICAgICByZXR1cm4gdG9rZW47XG4gICAgfSxcbiAgfSxcbiAgc2Vzc2lvbjoge1xuICAgIHN0cmF0ZWd5OiBcImp3dFwiLFxuICB9LFxufSk7XG4iXSwibmFtZXMiOlsiTmV4dEF1dGgiLCJDcmVkZW50aWFsc1Byb3ZpZGVyIiwiUHJpc21hQ2xpZW50IiwidmVyaWZ5UGFzc3dvcmQiLCJwcmlzbWEiLCJwcm92aWRlcnMiLCJuYW1lIiwiY3JlZGVudGlhbHMiLCJpZCIsImxhYmVsIiwidHlwZSIsInBsYWNlaG9sZGVyIiwicGFzc3dvcmQiLCJhdXRob3JpemUiLCJ1c2VyIiwiZmluZFVuaXF1ZSIsIndoZXJlIiwiU3RyaW5nIiwic2VsZWN0IiwiYWRkcmVzcyIsInVzZXJfc3JsIiwicHJvZmlsZV91cmwiLCJFcnJvciIsImlzVmFsaWQiLCJlbWFpbCIsImltYWdlIiwiY2FsbGJhY2tzIiwic2Vzc2lvbiIsInRva2VuIiwidWlkIiwiand0Iiwic3RyYXRlZ3kiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/auth/[...nextauth].tsx\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/auth/[...nextauth].tsx"));
module.exports = __webpack_exports__;

})();