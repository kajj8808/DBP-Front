"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/chat_list/get_list";
exports.ids = ["pages/api/chat_list/get_list"];
exports.modules = {

/***/ "@prisma/client":
/*!*********************************!*\
  !*** external "@prisma/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ "(api)/./pages/api/chat_list/get_list.ts":
/*!*****************************************!*\
  !*** ./pages/api/chat_list/get_list.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @prisma/client */ \"@prisma/client\");\n/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);\n\nasync function handler(req, res) {\n    let prisma = new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();\n    const data = req.body;\n    const { id  } = data;\n    const chatRoomList = await prisma.member.findMany({\n        where: {\n            user_id: id\n        },\n        distinct: [\n            \"room_id\"\n        ],\n        select: {\n            room_id: true\n        }\n    });\n    const getRoomInfo = await prisma.chatRoom.findMany({\n        where: {\n            room_id: {\n                in: chatRoomList.map((chatroom)=>chatroom.room_id)\n            }\n        },\n        select: {\n            room_id: true,\n            room_name: true,\n            members: true\n        }\n    });\n    if (getRoomInfo) {\n        res.status(201).json(getRoomInfo);\n    }\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvY2hhdF9saXN0L2dldF9saXN0LnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUM4QztBQUU5QyxlQUFlQyxRQUFRQyxHQUFtQixFQUFFQyxHQUFvQixFQUFFO0lBQ2hFLElBQUlDLFNBQVMsSUFBSUosd0RBQVlBO0lBRTdCLE1BQU1LLE9BQU9ILElBQUlJLElBQUk7SUFDckIsTUFBTSxFQUFFQyxHQUFFLEVBQUUsR0FBR0Y7SUFFZixNQUFNRyxlQUFlLE1BQU1KLE9BQU9LLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDO1FBQ2hEQyxPQUFPO1lBQ0xDLFNBQVNMO1FBQ1g7UUFDQU0sVUFBVTtZQUFDO1NBQVU7UUFDckJDLFFBQVE7WUFDTkMsU0FBUyxJQUFJO1FBQ2Y7SUFDRjtJQUVBLE1BQU1DLGNBQWMsTUFBTVosT0FBT2EsUUFBUSxDQUFDUCxRQUFRLENBQUM7UUFDakRDLE9BQU87WUFDTEksU0FBUztnQkFDUEcsSUFBSVYsYUFBYVcsR0FBRyxDQUFDLENBQUNDLFdBQWFBLFNBQVNMLE9BQU87WUFDckQ7UUFDRjtRQUNBRCxRQUFRO1lBQ05DLFNBQVMsSUFBSTtZQUNiTSxXQUFXLElBQUk7WUFDZkMsU0FBUyxJQUFJO1FBQ2Y7SUFDRjtJQUVBLElBQUlOLGFBQWE7UUFDZmIsSUFBSW9CLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUNSO0lBQ3ZCLENBQUM7QUFDSDtBQUVBLGlFQUFlZixPQUFPQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZGJwLWNoYXQvLi9wYWdlcy9hcGkvY2hhdF9saXN0L2dldF9saXN0LnRzP2IyMTEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmV4dEFwaVJlcXVlc3QsIE5leHRBcGlSZXNwb25zZSB9IGZyb20gXCJuZXh0XCI7XG5pbXBvcnQgeyBQcmlzbWFDbGllbnQgfSBmcm9tIFwiQHByaXNtYS9jbGllbnRcIjtcblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihyZXE6IE5leHRBcGlSZXF1ZXN0LCByZXM6IE5leHRBcGlSZXNwb25zZSkge1xuICBsZXQgcHJpc21hID0gbmV3IFByaXNtYUNsaWVudCgpO1xuXG4gIGNvbnN0IGRhdGEgPSByZXEuYm9keTtcbiAgY29uc3QgeyBpZCB9ID0gZGF0YTtcblxuICBjb25zdCBjaGF0Um9vbUxpc3QgPSBhd2FpdCBwcmlzbWEubWVtYmVyLmZpbmRNYW55KHtcbiAgICB3aGVyZToge1xuICAgICAgdXNlcl9pZDogaWQsXG4gICAgfSxcbiAgICBkaXN0aW5jdDogW1wicm9vbV9pZFwiXSxcbiAgICBzZWxlY3Q6IHtcbiAgICAgIHJvb21faWQ6IHRydWUsXG4gICAgfSxcbiAgfSk7XG5cbiAgY29uc3QgZ2V0Um9vbUluZm8gPSBhd2FpdCBwcmlzbWEuY2hhdFJvb20uZmluZE1hbnkoe1xuICAgIHdoZXJlOiB7XG4gICAgICByb29tX2lkOiB7XG4gICAgICAgIGluOiBjaGF0Um9vbUxpc3QubWFwKChjaGF0cm9vbSkgPT4gY2hhdHJvb20ucm9vbV9pZCksXG4gICAgICB9LFxuICAgIH0sXG4gICAgc2VsZWN0OiB7XG4gICAgICByb29tX2lkOiB0cnVlLFxuICAgICAgcm9vbV9uYW1lOiB0cnVlLFxuICAgICAgbWVtYmVyczogdHJ1ZSxcbiAgICB9LFxuICB9KTtcblxuICBpZiAoZ2V0Um9vbUluZm8pIHtcbiAgICByZXMuc3RhdHVzKDIwMSkuanNvbihnZXRSb29tSW5mbyk7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgaGFuZGxlcjtcbiJdLCJuYW1lcyI6WyJQcmlzbWFDbGllbnQiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwicHJpc21hIiwiZGF0YSIsImJvZHkiLCJpZCIsImNoYXRSb29tTGlzdCIsIm1lbWJlciIsImZpbmRNYW55Iiwid2hlcmUiLCJ1c2VyX2lkIiwiZGlzdGluY3QiLCJzZWxlY3QiLCJyb29tX2lkIiwiZ2V0Um9vbUluZm8iLCJjaGF0Um9vbSIsImluIiwibWFwIiwiY2hhdHJvb20iLCJyb29tX25hbWUiLCJtZW1iZXJzIiwic3RhdHVzIiwianNvbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/chat_list/get_list.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/chat_list/get_list.ts"));
module.exports = __webpack_exports__;

})();