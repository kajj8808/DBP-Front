/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./node_modules/@next/font/google/target.css?{\"path\":\"pages/_app.tsx\",\"import\":\"Roboto\",\"arguments\":[{\"weight\":\"400\",\"subsets\":[\"latin\"]}]}":
/*!**************************************************************************************************************************************************!*\
  !*** ./node_modules/@next/font/google/target.css?{"path":"pages/_app.tsx","import":"Roboto","arguments":[{"weight":"400","subsets":["latin"]}]} ***!
  \**************************************************************************************************************************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"style\": {\"fontFamily\":\"'__Roboto_19bf8f', '__Roboto_Fallback_19bf8f'\",\"fontWeight\":400,\"fontStyle\":\"normal\"},\n\t\"className\": \"__className_19bf8f\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvQG5leHQvZm9udC9nb29nbGUvdGFyZ2V0LmNzcz97XCJwYXRoXCI6XCJwYWdlcy9fYXBwLnRzeFwiLFwiaW1wb3J0XCI6XCJSb2JvdG9cIixcImFyZ3VtZW50c1wiOlt7XCJ3ZWlnaHRcIjpcIjQwMFwiLFwic3Vic2V0c1wiOltcImxhdGluXCJdfV19LmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQSxXQUFXLG1HQUFtRztBQUM5RztBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZGJwLWNoYXQvLi9ub2RlX21vZHVsZXMvQG5leHQvZm9udC9nb29nbGUvdGFyZ2V0LmNzcz82ZDEwIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcInN0eWxlXCI6IHtcImZvbnRGYW1pbHlcIjpcIidfX1JvYm90b18xOWJmOGYnLCAnX19Sb2JvdG9fRmFsbGJhY2tfMTliZjhmJ1wiLFwiZm9udFdlaWdodFwiOjQwMCxcImZvbnRTdHlsZVwiOlwibm9ybWFsXCJ9LFxuXHRcImNsYXNzTmFtZVwiOiBcIl9fY2xhc3NOYW1lXzE5YmY4ZlwiXG59O1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./node_modules/@next/font/google/target.css?{\"path\":\"pages/_app.tsx\",\"import\":\"Roboto\",\"arguments\":[{\"weight\":\"400\",\"subsets\":[\"latin\"]}]}\n");

/***/ }),

/***/ "./components/Toast.tsx":
/*!******************************!*\
  !*** ./components/Toast.tsx ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-toastify */ \"react-toastify\");\n/* harmony import */ var _context_socket__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @context/socket */ \"./context/socket.ts\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_1__, _context_socket__WEBPACK_IMPORTED_MODULE_2__]);\n([react_toastify__WEBPACK_IMPORTED_MODULE_1__, _context_socket__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{\n    const socket = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context_socket__WEBPACK_IMPORTED_MODULE_2__.SocketContext);\n    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{\n        socket.on(\"notify\", (text)=>{\n            react_toastify__WEBPACK_IMPORTED_MODULE_1__.toast.info(text, {\n                autoClose: 2000,\n                position: \"top-right\",\n                closeOnClick: true,\n                pauseOnHover: true,\n                draggable: true,\n                icon: \"\\uD83D\\uDD14\",\n                progress: undefined\n            });\n        });\n    }, []);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_toastify__WEBPACK_IMPORTED_MODULE_1__.ToastContainer, {}, void 0, false, {\n        fileName: \"/home/sss003366/DBP/dbp_chat_project/components/Toast.tsx\",\n        lineNumber: 34,\n        columnNumber: 10\n    }, undefined);\n});\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL1RvYXN0LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUE7QUFPd0I7QUFDd0I7QUFDRjtBQU85QyxpRUFBZSxJQUFNO0lBQ25CLE1BQU1LLFNBQVNGLGlEQUFVQSxDQUFDRCwwREFBYUE7SUFFdkNFLGdEQUFTQSxDQUFDLElBQU07UUFDZEMsT0FBT0MsRUFBRSxDQUFDLFVBQVUsQ0FBQ0MsT0FBUztZQUM1Qk4sc0RBQVUsQ0FBQ00sTUFBTTtnQkFDZkUsV0FBVztnQkFDWEMsVUFBVTtnQkFDVkMsY0FBYyxJQUFJO2dCQUNsQkMsY0FBYyxJQUFJO2dCQUNsQkMsV0FBVyxJQUFJO2dCQUNmQyxNQUFNO2dCQUNOQyxVQUFVQztZQUNaO1FBQ0Y7SUFDRixHQUFHLEVBQUU7SUFFTCxxQkFBTyw4REFBQ2hCLDBEQUFjQTs7Ozs7QUFDeEIsR0FBRSIsInNvdXJjZXMiOlsid2VicGFjazovL2RicC1jaGF0Ly4vY29tcG9uZW50cy9Ub2FzdC50c3g/OTM5YSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBUb2FzdENvbnRhaW5lcixcbiAgdG9hc3QsXG4gIFpvb20sXG4gIEJvdW5jZSxcbiAgRmxpcCxcbiAgU2xpZGUsXG59IGZyb20gXCJyZWFjdC10b2FzdGlmeVwiO1xuaW1wb3J0IHsgU29ja2V0Q29udGV4dCB9IGZyb20gXCJAY29udGV4dC9zb2NrZXRcIjtcbmltcG9ydCB7IHVzZUNvbnRleHQsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW50ZXJmYWNlIElOb3RpZnkge1xuICBtZXNzYWdlOiBzdHJpbmc7XG4gIHNlbmRlcjogc3RyaW5nO1xuICBhdmF0YXI6IHN0cmluZztcbn1cblxuZXhwb3J0IGRlZmF1bHQgKCkgPT4ge1xuICBjb25zdCBzb2NrZXQgPSB1c2VDb250ZXh0KFNvY2tldENvbnRleHQpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc29ja2V0Lm9uKFwibm90aWZ5XCIsICh0ZXh0KSA9PiB7XG4gICAgICB0b2FzdC5pbmZvKHRleHQsIHtcbiAgICAgICAgYXV0b0Nsb3NlOiAyMDAwLFxuICAgICAgICBwb3NpdGlvbjogXCJ0b3AtcmlnaHRcIixcbiAgICAgICAgY2xvc2VPbkNsaWNrOiB0cnVlLFxuICAgICAgICBwYXVzZU9uSG92ZXI6IHRydWUsXG4gICAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcbiAgICAgICAgaWNvbjogXCLwn5SUXCIsXG4gICAgICAgIHByb2dyZXNzOiB1bmRlZmluZWQsXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiA8VG9hc3RDb250YWluZXIgLz47XG59O1xuIl0sIm5hbWVzIjpbIlRvYXN0Q29udGFpbmVyIiwidG9hc3QiLCJTb2NrZXRDb250ZXh0IiwidXNlQ29udGV4dCIsInVzZUVmZmVjdCIsInNvY2tldCIsIm9uIiwidGV4dCIsImluZm8iLCJhdXRvQ2xvc2UiLCJwb3NpdGlvbiIsImNsb3NlT25DbGljayIsInBhdXNlT25Ib3ZlciIsImRyYWdnYWJsZSIsImljb24iLCJwcm9ncmVzcyIsInVuZGVmaW5lZCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/Toast.tsx\n");

/***/ }),

/***/ "./context/socket.ts":
/*!***************************!*\
  !*** ./context/socket.ts ***!
  \***************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"SocketContext\": () => (/* binding */ SocketContext),\n/* harmony export */   \"socket\": () => (/* binding */ socket)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! socket.io-client */ \"socket.io-client\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([socket_io_client__WEBPACK_IMPORTED_MODULE_1__]);\nsocket_io_client__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\nconst SERVER_URL = \"http://localhost:4000\";\nconsole.log(process.env.SOCKET_SERVER);\nconst socket = (0,socket_io_client__WEBPACK_IMPORTED_MODULE_1__[\"default\"])(SERVER_URL);\nconst SocketContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(socket);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb250ZXh0L3NvY2tldC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFzQztBQUNFO0FBRXhDLE1BQU1FLGFBQWFDLHVCQUFxQztBQUV4REcsUUFBUUMsR0FBRyxDQUFDSixRQUFRQyxHQUFHLENBQUNJLGFBQWE7QUFFOUIsTUFBTUMsU0FBU1IsNERBQVFBLENBQUNDLFlBQVk7QUFDcEMsTUFBTVEsZ0JBQWdCVixvREFBYUEsQ0FBQ1MsUUFBUSIsInNvdXJjZXMiOlsid2VicGFjazovL2RicC1jaGF0Ly4vY29udGV4dC9zb2NrZXQudHM/MzRmYSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgc29ja2V0aW8gZnJvbSBcInNvY2tldC5pby1jbGllbnRcIjtcblxuY29uc3QgU0VSVkVSX1VSTCA9IHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX1NPQ0tFVF9TRVJWRVI7XG5cbmNvbnNvbGUubG9nKHByb2Nlc3MuZW52LlNPQ0tFVF9TRVJWRVIpO1xuXG5leHBvcnQgY29uc3Qgc29ja2V0ID0gc29ja2V0aW8oU0VSVkVSX1VSTCk7XG5leHBvcnQgY29uc3QgU29ja2V0Q29udGV4dCA9IGNyZWF0ZUNvbnRleHQoc29ja2V0KTtcbiJdLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0Iiwic29ja2V0aW8iLCJTRVJWRVJfVVJMIiwicHJvY2VzcyIsImVudiIsIk5FWFRfUFVCTElDX1NPQ0tFVF9TRVJWRVIiLCJjb25zb2xlIiwibG9nIiwiU09DS0VUX1NFUlZFUiIsInNvY2tldCIsIlNvY2tldENvbnRleHQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./context/socket.ts\n");

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _next_font_google_target_css_path_pages_app_tsx_import_Roboto_arguments_weight_400_subsets_latin___WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @next/font/google/target.css?{\"path\":\"pages/_app.tsx\",\"import\":\"Roboto\",\"arguments\":[{\"weight\":\"400\",\"subsets\":[\"latin\"]}]} */ \"./node_modules/@next/font/google/target.css?{\\\"path\\\":\\\"pages/_app.tsx\\\",\\\"import\\\":\\\"Roboto\\\",\\\"arguments\\\":[{\\\"weight\\\":\\\"400\\\",\\\"subsets\\\":[\\\"latin\\\"]}]}\");\n/* harmony import */ var _next_font_google_target_css_path_pages_app_tsx_import_Roboto_arguments_weight_400_subsets_latin___WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_next_font_google_target_css_path_pages_app_tsx_import_Roboto_arguments_weight_400_subsets_latin___WEBPACK_IMPORTED_MODULE_7__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ \"./node_modules/react-toastify/dist/ReactToastify.css\");\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next-auth/react */ \"next-auth/react\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var context_socket__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! context/socket */ \"./context/socket.ts\");\n/* harmony import */ var _components_Toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @components/Toast */ \"./components/Toast.tsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([context_socket__WEBPACK_IMPORTED_MODULE_5__, _components_Toast__WEBPACK_IMPORTED_MODULE_6__]);\n([context_socket__WEBPACK_IMPORTED_MODULE_5__, _components_Toast__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\nfunction App({ Component , pageProps  }) {\n    console.log(\"App is Running\");\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Toast__WEBPACK_IMPORTED_MODULE_6__[\"default\"], {}, void 0, false, {\n                fileName: \"/home/sss003366/DBP/dbp_chat_project/pages/_app.tsx\",\n                lineNumber: 23,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_auth_react__WEBPACK_IMPORTED_MODULE_3__.SessionProvider, {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(context_socket__WEBPACK_IMPORTED_MODULE_5__.SocketContext.Provider, {\n                    value: context_socket__WEBPACK_IMPORTED_MODULE_5__.socket,\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        className: (_next_font_google_target_css_path_pages_app_tsx_import_Roboto_arguments_weight_400_subsets_latin___WEBPACK_IMPORTED_MODULE_7___default().className),\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_4___default()), {\n                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"title\", {\n                                    children: \"GOOD LUCK CHAT\"\n                                }, void 0, false, {\n                                    fileName: \"/home/sss003366/DBP/dbp_chat_project/pages/_app.tsx\",\n                                    lineNumber: 28,\n                                    columnNumber: 15\n                                }, this)\n                            }, void 0, false, {\n                                fileName: \"/home/sss003366/DBP/dbp_chat_project/pages/_app.tsx\",\n                                lineNumber: 27,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                                id: \"modal\"\n                            }, void 0, false, {\n                                fileName: \"/home/sss003366/DBP/dbp_chat_project/pages/_app.tsx\",\n                                lineNumber: 30,\n                                columnNumber: 13\n                            }, this),\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                                ...pageProps\n                            }, void 0, false, {\n                                fileName: \"/home/sss003366/DBP/dbp_chat_project/pages/_app.tsx\",\n                                lineNumber: 31,\n                                columnNumber: 13\n                            }, this)\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/home/sss003366/DBP/dbp_chat_project/pages/_app.tsx\",\n                        lineNumber: 26,\n                        columnNumber: 11\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"/home/sss003366/DBP/dbp_chat_project/pages/_app.tsx\",\n                    lineNumber: 25,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"/home/sss003366/DBP/dbp_chat_project/pages/_app.tsx\",\n                lineNumber: 24,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQVlNQTtBQVp5QjtBQUNnQjtBQUlHO0FBRXJCO0FBRTBCO0FBQ2pCO0FBT3ZCLFNBQVNNLElBQUksRUFBRUMsVUFBUyxFQUFFQyxVQUFTLEVBQVksRUFBRTtJQUM5REMsUUFBUUMsR0FBRyxDQUFDO0lBRVoscUJBQ0U7OzBCQUNFLDhEQUFDTCx5REFBS0E7Ozs7OzBCQUNOLDhEQUFDSiw0REFBZUE7MEJBQ2QsNEVBQUNHLGtFQUFzQjtvQkFBQ1EsT0FBT1Qsa0RBQU1BOzhCQUNuQyw0RUFBQ1U7d0JBQUlDLFdBQVdkLG9KQUFnQjs7MENBQzlCLDhEQUFDRSxrREFBSUE7MENBQ0gsNEVBQUNhOzhDQUFNOzs7Ozs7Ozs7OzswQ0FFVCw4REFBQ0Y7Z0NBQUlHLElBQUc7Ozs7OzswQ0FDUiw4REFBQ1Q7Z0NBQVcsR0FBR0MsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBTXBDLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9kYnAtY2hhdC8uL3BhZ2VzL19hcHAudHN4PzJmYmUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL2dsb2JhbHMuY3NzXCI7XG5pbXBvcnQgXCJyZWFjdC10b2FzdGlmeS9kaXN0L1JlYWN0VG9hc3RpZnkuY3NzXCI7XG5pbXBvcnQgeyBSb2JvdG8gfSBmcm9tIFwiQG5leHQvZm9udC9nb29nbGVcIjtcblxuaW1wb3J0IHR5cGUgeyBBcHBQcm9wcyB9IGZyb20gXCJuZXh0L2FwcFwiO1xuaW1wb3J0IHsgU2Vzc2lvblByb3ZpZGVyIH0gZnJvbSBcIm5leHQtYXV0aC9yZWFjdFwiO1xuXG5pbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XG5pbXBvcnQgeyBjcmVhdGVDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBzb2NrZXQsIFNvY2tldENvbnRleHQgfSBmcm9tIFwiY29udGV4dC9zb2NrZXRcIjtcbmltcG9ydCBUb2FzdCBmcm9tIFwiQGNvbXBvbmVudHMvVG9hc3RcIjtcblxuY29uc3Qgcm9ib3RvID0gUm9ib3RvKHtcbiAgd2VpZ2h0OiBcIjQwMFwiLFxuICBzdWJzZXRzOiBbXCJsYXRpblwiXSxcbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykge1xuICBjb25zb2xlLmxvZyhcIkFwcCBpcyBSdW5uaW5nXCIpO1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxUb2FzdCAvPlxuICAgICAgPFNlc3Npb25Qcm92aWRlcj5cbiAgICAgICAgPFNvY2tldENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3NvY2tldH0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3JvYm90by5jbGFzc05hbWV9PlxuICAgICAgICAgICAgPEhlYWQ+XG4gICAgICAgICAgICAgIDx0aXRsZT5HT09EIExVQ0sgQ0hBVDwvdGl0bGU+XG4gICAgICAgICAgICA8L0hlYWQ+XG4gICAgICAgICAgICA8ZGl2IGlkPVwibW9kYWxcIj48L2Rpdj5cbiAgICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9Tb2NrZXRDb250ZXh0LlByb3ZpZGVyPlxuICAgICAgPC9TZXNzaW9uUHJvdmlkZXI+XG4gICAgPC8+XG4gICk7XG59XG4iXSwibmFtZXMiOlsicm9ib3RvIiwiU2Vzc2lvblByb3ZpZGVyIiwiSGVhZCIsInNvY2tldCIsIlNvY2tldENvbnRleHQiLCJUb2FzdCIsIkFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsImNvbnNvbGUiLCJsb2ciLCJQcm92aWRlciIsInZhbHVlIiwiZGl2IiwiY2xhc3NOYW1lIiwidGl0bGUiLCJpZCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./node_modules/react-toastify/dist/ReactToastify.css":
/*!************************************************************!*\
  !*** ./node_modules/react-toastify/dist/ReactToastify.css ***!
  \************************************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "next-auth/react":
/*!**********************************!*\
  !*** external "next-auth/react" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react-toastify":
/*!*********************************!*\
  !*** external "react-toastify" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ }),

/***/ "socket.io-client":
/*!***********************************!*\
  !*** external "socket.io-client" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = import("socket.io-client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();