self.__FONT_LOADER_MANIFEST={
  "pages": {
    "/_app": [
      "static/media/934c4b7cb736f2a3.p.woff2"
    ]
  },
  "app": {}
}