import AdminLayout from "@components/AdminLayout"

export default () => {
    return (
        <AdminLayout>
            <p>메뉴를 선택하세요.</p>
        </AdminLayout>
    )
}